var canv = document.getElementById("gameCanvas");
c = canv.getContext("2d");



var i = 0;
var j = 0;
var score1 = 0;
var score2 = 0;
var score3 = 0;

var win_cond = 0;

var players = sessionStorage.getItem("players");

//  console.log(players);

//LOSING SOUND
var sound = new Audio();
sound.src = "items\\sound.mp3";
var bullet_sound = new Audio();
bullet_sound.src = "items\\Pop Trim.mp3";
var power_sound = new Audio();
power_sound.src = "items\\powerup.mp3";
var bullet_speed = 3.9;

//MAP IMAGE
// var map_image = new Image();
// var data = [];
// var x = 220;
// var y = 140;
// class point{
//     constructor(x, y){
//         this.x = x;
//         this.y = y;
//     }
//     getx(){
//         return this.x;
//     }
//     gety(){
//         return this.y;
//     }
// };

// var points = [];
// map_image.src = "pixil-frame-1.png";
// map_image.crossOrigin = "Anonymous";
// map_image.onload = function() {
//     // console.log("Ali Ammar");
//     c.drawImage(map_image, 0, 0, canv.width, canv.height);
//     const scannedImage = c.getImageData(0, 0, canv.width, canv.height);
//     data = scannedImage.data;
//     console.log(data.length);    
//     console.log(data[16]);    
//     console.log(data[17]);    
//     console.log(data[28]);    
//     console.log(data[19]);    
// }

// function draw_map(startx, starty, endx, endy){
//     var i = startx;
//     var j = starty;
//     while(i <= endx || j <= endy){
//         var p = new point(x, y);
//         points.push(p);
//         if (i <= endx){
//             i++;
//         }
//         if (j <= endy){
//             j++;
//         }
//     }
//     c.strokeStyle = "#ffffff";
//     c.beginPath();
//     c.moveTo(startx, starty);
//     c.lineTo(endx, endy);
//     c.stroke();
// }

// function draw_maps(startx, starty, endx, endy){
//     // var i = startx;
//     // var j = starty;
//     // while(i <= endx || j <= endy){
//     //     var p = new point(x, y);
//     //     points.push(p);
//     //     if (i <= endx){
//     //         i++;
//     //     }
//     //     if (j <= endy){
//     //         j++;
//     //     }
//     // }
//     c.strokeStyle = "#ffffff";
//     c.beginPath();
//     c.moveTo(startx, starty);
//     c.lineTo(endx, endy);
//     c.stroke();
// }
//POWER UPS
POWER_UP = {
    simple: true,
    bomb: false
};

//ANIMATION IMAGES
var fire_image1 = new Image();
fire_image1.src = "items\\PNG\\Effects\\Flame_A.png";
var fire_image2 = new Image();
fire_image2.src = "items\\PNG\\Effects\\Flame_C.png";
//POWERUP
var power = new Image();
power.src = "items\\Lovepik_com-401727266-bomb.png";


// function fire1(tank){
//     c.drawImage(fire_image1, tank.x + tank.w, tank.y + (tank.h / 2) - (fire_image1.height / 2), fire_image1.width, fire_image1.height);
// }
// function fire2(tank){
//     c.drawImage(fire_image2, tank.x + tank.w, tank.y + (tank.h / 2) - (fire_image2.height / 2), fire_image2.width, fire_image2.height);
// }

// function firing_animation(tank){
//     c.save();
//     c.translate(tank.x + tank.w / 2, tank.y + tank.h / 2);
//     c.rotate(tank.angle);
//     c.translate(-(tank.x + tank.w / 2), -(tank.y + tank.h / 2));
//     setTimeout(fire1(tank), 2000);
//     setTimeout(fire2(tank), 2000);
//     c.restore();
// }

//BACKGROUND IMAGE
var background_image = new Image(); 
background_image.src = "items\\background_images\\wp2178737-black-game-wallpapers.jpg";



//Tank1_Image
var Tank1_image = new Image();
Tank1_image.src = "items\\PNG\\Hulls_Color_D\\Hull_02.png";
var Tank1_weapon = new Image();
Tank1_weapon.src = "items\\PNG\\Weapon_Color_D_256X256\\Gun_02.png";
//Tank2_Image
var Tank2_image = new Image();
Tank2_image.src = "items\\PNG\\Hulls_Color_B\\Hull_02.png";
var Tank2_weapon = new Image();
Tank2_weapon.src = "items\\PNG\\Weapon_Color_B_256X256\\Gun_02.png";
//Tank3_image
var Tank3_image = new Image();
Tank3_image.src = "items\\PNG\\Hulls_Color_C\\Hull_02.png";
var Tank3_weapon = new Image();
Tank3_weapon.src = "items\\PNG\\Weapon_Color_C\\Gun_02.png";
//BACKGROUND IMAGE

//CLEARING FUNCTION

var bullet_image = new Image();
bullet_image.src = "items\\PNG\\Effects\\Plasma.png";


//BLOWING UP THE TANK

var blow1 = new Image();
var blow2 = new Image();
var blow3 = new Image();
var blow4 = new Image();
var blow5 = new Image();
var blow6 = new Image();
var blow7 = new Image();
var blow8 = new Image();
var blow9 = new Image();
blow1.src = "items\\PNG\\Effects\\Explosion_A.png";
blow2.src = "items\\PNG\\Effects\\Explosion_B.png";
blow3.src = "items\\PNG\\Effects\\Explosion_C.png";
blow4.src = "items\\PNG\\Effects\\Explosion_D.png";
blow5.src = "items\\PNG\\Effects\\Explosion_E.png";
blow6.src = "items\\PNG\\Effects\\Explosion_F.png";
blow7.src = "items\\PNG\\Effects\\Explosion_G.png";
blow8.src = "items\\PNG\\Effects\\Explosion_H.png";

var bomb_images = [];
bomb_images.push(blow1, blow2, blow3, blow4, blow5, blow6, blow7, blow8);

var explosion = new Image();
explosion.src = "items\\explosion.jpg";
var width = 650;
var height = 650;
var rows = 5;
var col = 6;
var w = width / col;
var h = height / rows;

var curframe = 0;
var frames = 5;

var srcx = -1;
var srcy = 0;



function updateFrame(){
    // curframe = ++curframe;
    // srcx = curframe * w;
    // if (curframe == 8){
    //     curframe == 0;
    //     srcy += h;
    //     srcy = srcy % height;   
    // }
    srcx++;
    srcx = srcx % bomb_images.length;    
}
function draw(x, y, w, h){
    c.clearRect(0, 0, canv.width, canv.height);
    updateFrame();
    // c.drawImage(explosion, srcx, srcy, w, h, 100, 100, w, h);
    c.drawImage(bomb_images[srcx], x, y, w, h);
}



// var temp = canv.width / 12;
// var t = 0;
// for (var i = 0;i < canv.width;i += temp){
//     c.strokeStyle = "#ffffff";
//     c.lineWidth = 5;
//     c.strokeRect(0 + i, 0, temp, temp);
//     t++;
//     console.log(t);
// }



var pressedKeys = {};
var Tank1_KEYS = {
        ARROW_LEFT: 37,
        ARROW_UP: 38,
        ARROW_RIGHT: 39,
        ARROW_DOWN: 40,
        SHOOT_KEY: 77
};
var Tank2_KEYS = {
    ARROW_UP: 87,
    ARROW_LEFT: 65,
    ARROW_RIGHT: 68,
    ARROW_DOWN: 83,
    SHOOT_KEY: 81
};
var Tank3_KEYS = {
    ARROW_UP: 73,
    ARROW_LEFT: 74,
    ARROW_RIGHT: 76,
    ARROW_DOWN: 75,
    SHOOT_KEY: 85 
};
var obstacle = {
    x: 200,
    y: 200,
    w: 20,
    h: 200
};
var oy = {
    x : 250,
    y: 300,
    w: 200,
    h: 20
}
class obstaclex{
    constructor(x, y, w, h){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
    draw(){
        c.fillStyle = "cyan";
        c.fillRect(this.x, this.y, this.w, this.h);
    }
    getx(){
        return this.x;
    }
    gety(){
        return this.y;
    }
    getw(){
        return this.w;
    }
    geth(){
        return this.h;
    }
    setx(x){
        this.x = x;
    }
    sety(y){
        this.y = y;
    }
};
class obstacley{
    constructor(x, y, w, h){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
    draw(){
        c.fillStyle = "cyan";
        c.fillRect(this.x, this.y, this.w, this.h);
    }
    getx(){
        return this.x;
    }
    gety(){
        return this.y;
    }
    getw(){
        return this.w;
    }
    geth(){
        return this.h;
    }
    setx(x){
        this.x = x;
    }
    sety(y){
        this.y = y;
    }
};
var ox = [];
var oy = [];
var cond = 0;







// ox.forEach((o) => {
//     if (o.getx())
// });

function create_map(){
    ox.forEach((o) => {
        o.draw();
    });
    oy.forEach((o) => {
        o.draw();
    });
}


//BULLETS
const bullets = [];
class bullet{
    constructor(x, y, radius, velocityx, velocityy, tank, duration, color){
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.velocityx = velocityx;
        this.velocityy = velocityy;
        this.tank = tank;
        this.duration = duration;
        this.color = color;
    }
    check_color(){
        if (this.color == "red"){
            return true;
        }
        else{
            return false;
        }
    }
    set_duration(d){
        this.duration = d;
    }
    draw(){
        c.beginPath();
        c.fillStyle = this.color;
        c.arc(this.x, this.y, this.radius, 0, 2 * Math.PI);      
        c.fill();
    }
    update(){
        c.clearRect(0, 0, canv.width, canv.height);   
        // c.drawImage(map_image, 0, 0, canv.width, canv.height);
        draw_all();
        if (!Tank1.destroyed){
            Draw_tank1();
        }
        if (!Tank2.destroyed){
            Draw_tank2();
        }
        if (!Tank3.destroyed){
            Draw_tank3();
        }
        this.x += this.velocityx;
        this.y += this.velocityy;
        // console.log(getData(this.x, this.y));
        // draw_all();
        // draw_all();
        this.collision_y();
        this.collision_x();    
    }
    check(){
        if (this.x > canv.width || this.y > canv.height || this.x < 0 || this.y < 0){
            return true;
        }
    }
    collision_y(){
        if((this.y + this.velocityy) < 5 || (this.y + this.velocityy) > canv.height - 5){
            this.velocityy = -1 * this.velocityy;
        }
    }
    collision_x(){
        if ((this.x + this.velocityx) < 5 || (this.x + this.velocityx) > canv.width - 5){
            this.velocityx = -1 * this.velocityx;
        }
    }
    xr(){
        return this.x + this.radius;  
    }
    yr(){
        return this.y + this.radius;
    }
    get_x(){
        return this.x;
    }
    get_y(){
        return this.y;
    }
    first_update(){
        this.x += this.velocityx * (this.tank.w / 5);
        this.y += this.velocityy * (this.tank.h / 5);
    }
    reduce(){
        // console.log(this.duration);
        this.duration--;
    }
    bullet_end(){
        if (this.duration <= 0){
            return true;
        }
    }
    get_tank(){
        return this.tank;
    }
    check_obstacle(){
        oy.forEach((o) => {
            if (this.x + this.velocityx >= o.getx() && this.y + this.velocityy >= o.gety() && this.x + this.velocityx <= (o.getx() + o.getw()) && this.y + this.velocityy <= (o.gety() + o.geth())){
                // console.log("COLLIDED X");
                // if (this.x + this.velocityx <= o.getx() + o.getw() || this.x + this.velocitx >= o.getx()){
                //     this.velocityx = -1 * this.velocityx;
                // }
                if (this.get_x() <= o.getx()){
                    this.velocityx = -1 * this.velocityx;
                }
                else{
                    if (this.get_x() >= o.getx() + o.getw()){
                        this.velocityx = -1 * this.velocityx;
                    }
                    else{
                        if (this.get_y() <= o.gety()){
                            this.velocityy = -1 * this.velocityy;
                        }
                        else{
                            if (this.get_y() >= o.gety() + o.geth()){
                                this.velocityy = -1 * this.velocityy;
                            }
                        }
                    }
                }
                


                if (this.x < o.getx() + o.getw() && this.x > o.getx() && this.y < o.gety() + o.geth() && this.y > o.gety()){
                    // this.velocityy = this.velocityy * -1;
                    // this.velocityx = this.velocityx * -1;
                    console.log("COLLISION Y");
                    if (this.tank != null){
                    this.tank.destroyed = true;
                    }
                    this.tank.bullet_count--;
                    bullets.splice(bullets.indexOf(this), 1);          
                    this.tank.x = -50;
                    this.tank.y = -40;
                    this.tank.WEAPON.x = -50;
                    this.tank.WEAPON.y = -50;
                    sound.play();
            setTimeout(function() {
                sound.pause();
                sound.currentTime = 0;
            }, 900);
                    c.clearRect(0, 0, canv.width, canv.height);
                }
            // var distx = Math.abs(this.get_x() - (o.getx() + o.getw() / 2));
            // var disty = Math.abs(this.get_y() - (o.gety() + o.geth() / 2));
            // if ((distx <= (o.getw() / 2)) && (disty <= (o.geth() / 2))){
            //     if (this.get_x() < o.getx()){
            //         console.log("LEFT SIDE");
            //         this.velocityx = -1 * this.velocityx;
            //     }
                
            //         if (this.get_x() > o.getx() + o.getw()){
            //             this.velocityx = -1 * this.velocityx;
            //         }
                
            //     if (this.get_y() < o.gety()){
            //         this.velocityy = -1 * this.velocityy;
            //     }
                
            //         if (this.get_y() > o.gety() + o.geth()){
            //             this.velocityy = -1 * this.velocityy;
            //         }
            //         this.velocityx = -1 * this.velocityx;
                
                // console.log("Collision");
            }
        });
        ox.forEach((o) => {
            if (this.x + this.velocityx >= o.getx() && this.y + this.velocityy >= o.gety() && this.x + this.velocityx <= (o.getx() + o.getw()) && this.y + this.velocityy <= (o.gety() + o.geth())){
                // console.log("COLLIDED Y");
                // if (this.y + this.velocityy <= o.gety() + o.geth() || this.y + this.velocityy >= o.gety()){
                //     this.velocityy = -1 * this.velocityy;
                // }
                if (this.get_x() <= o.getx()){
                    this.velocityx = -1 * this.velocityx;
                }
                else{
                    if (this.get_x() >= o.getx() + o.getw()){
                        this.velocityx = -1 * this.velocityx;
                    }
                    else{
                        if (this.get_y() <= o.gety()){
                            this.velocityy = -1 * this.velocityy;
                        }
                        else{
                            if (this.get_y() >= o.gety() + o.geth()){
                                this.velocityy = -1 * this.velocityy;
                            }
                        }
                    }
                }
                


                if (this.x < o.getx() + o.getw() && this.x > o.getx() && this.y < o.gety() + o.geth() && this.y > o.gety()){
                    // this.velocityy = this.velocityy * -1;
                    // this.velocityx = this.velocityx * -1;
                    console.log("COLLISION X");
                    this.tank.destroyed = true;
                    this.tank.bullet_count--;
                    bullets.splice(bullets.indexOf(this), 1);          
                    this.tank.x = -50;
                    this.tank.y = -40;
                    this.tank.WEAPON.x = -50;
                    this.tank.WEAPON.y = -50;
                    sound.play();
            setTimeout(function() {
                sound.pause();
                sound.currentTime = 0;
            }, 900);
                    c.clearRect(0, 0, canv.width, canv.height);
                }
            }
            // var distx = Math.abs(this.get_x() - (o.getx() + o.getw() / 2));
            // var disty = Math.abs(this.get_y() - (o.gety() + o.geth() / 2));
            // if ((distx <= (o.getw() / 2)) && (disty <= (o.geth() / 2))){
            //     if (this.get_x() < o.getx()){
            //         console.log("LEFT SIDE");
            //         this.velocityx = -1 * this.velocityx;
            //     }
            //         if (this.get_x() > o.getx() + o.getw()){
            //             this.velocityx = -1 * this.velocityx;
            //         }
                
            //     if (this.get_y() < o.gety()){
            //         this.velocityy = -1 * this.velocityy;
            //     }
                
            //         if (this.get_y() > o.gety() + o.geth()){
            //             this.velocityy = -1 * this.velocityy;
            //         }
            //         this.velocityy = -1 * this.velocityy;
                
                // console.log("Collision");
            // }       
        });
    //     if (this.x + this.velocityx >= obstacle.x && this.y + this.velocityy >= obstacle.y && this.x + this.velocityx <= (obstacle.x + obstacle.w) && this.y + this.velocityy <= (obstacle.y + obstacle.h)){
    //         console.log("COLLIDED X");
    //         if (this.x + this.velocityx <= obstacle.x + obstacle.w || this.x + this.velocitx >= obstacle.x){
    //             this.velocityx = -1 * this.velocityx;
    //         }
    //     }
    //     if (this.x + this.velocityx >= oy.x && this.y + this.velocityy >= oy.y && this.x + this.velocityx <= (oy.x + oy.w) && this.y + this.velocityy <= (oy.y + oy.h)){
    //         console.log("COLLIDED Y");
    //         if (this.y + this.velocityy <= oy.y + oy.h){
    //             this.velocityy = -1 * this.velocityy;
    //         }
    //     }
    }
};

function draw_explosion(tank){
    c.drawImage(blow5, tank.x, tank.y, tank.w, tank.h);
}


var exp_cond = 0;

function collision(tank){
    bullets.forEach((b) => {
        if ((b.get_x() >= tank.x) && (b.get_y() >= tank.y) && ((tank.x + tank.w) >= b.get_x()) && ((tank.y + tank.h) >= b.get_y())){
            // console.log("YES");
            
            tank.destroyed = true;
            if (b.get_tank() != null){
                b.get_tank().bullet_count--;
            }
            bullets.splice(bullets.indexOf(b), 1);
            tank.x = -50;
            tank.y = -40;
            tank.WEAPON.x = -50;
            tank.WEAPON.y = -50;
            c.clearRect(0, 0, canv.width, canv.height);
            if (sound.duration > 0 && !sound.paused){
                sound.currentTime = 0;
                sound.play();
            }else{
                sound.play();
            }
            sound.play();
            // setTimeout(function() {
            //     sound.pause();
            //     sound.currentTime = 0;
            // }, 900);
            
        }
        // b.restoring();
    });
};
function draw_all(){
    // c.drawImage(map_image, 0, 0, canv.width, canv.height);
    create_map();   
    showing_bomb(); 
    
    // c.drawImage(background_image, 0, 0, canv.width, canv.height);
    bullets.forEach((b)=> {
        create_map();    
        // firing_animation(Tank1);

        b.draw();
        b.reduce();
        b.check_obstacle();
        // b.restoring();
    });
};
// var bullet = {
//     x: 5,
//     y: 5,
//     r: 5,
//     velocity: {
//         x: 0,
//         y: 0
//     }
// };
document.onkeydown = function (e) {
    // console.log(e.keyCode);
    pressedKeys[e.keyCode] = true;

}
document.onkeyup = function (e) {
    pressedKeys[e.keyCode] = false;
}
var Tank1 = {
    x: 25,
    y: 25,
    w: 40,
    h: 40,
    angle: 0,
    speed: 2,
    rSpeed: 5,
    destroyed: false,
    WEAPON: {
        x: 25, 
        y: 35,
        w: 50,
        h: 20
    },
    bullet_count: 0,
    normal: true,
    bomb: false
};
var Tank2 = {
    x: 430,
    y: 440,
    w: 40,
    h: 40,
    angle: 0,
    speed: 2,
    rSpeed: 5,
    destroyed: false,
    WEAPON: {
        x: 430, 
        y: 450,
        w: 50,
        h: 20
    },
    bullet_count: 0,
    normal: true,
    bomb: false
};
var Tank3 = {
    x: 830,
    y: 25,
    w: 40,
    h: 40,
    angle: 0,
    speed: 2,
    rSpeed: 5,
    destroyed: false,
    WEAPON: {
        x: 830, 
        y: 35,
        w: 50,
        h: 20
    },
    bullet_count: 0,
    normal: true,
    bomb: false
};











if (players == "2"){
    Tank3.destroyed = true;
    Tank3.x = -50;
    Tank3.y = -50;
    Tank3.WEAPON.x = -50;
    Tank3.WEAPON.y = -40;
}








function drawimg_map(){
    var time = 3;
    // console.log(win_cond);
    // console.log("1: " + Tank1.destroyed);
    // console.log("2: " + Tank2.destroyed);
    // console.log(Tank1.destroyed);
    // console.log("1: " + Tank1.destroyed);
    // console.log("2: " + Tank2.destroyed);
    // console.log("3: " + Tank3.destroyed);
    // console.log(Tank2.destroyed);
    // console.log(Tank3.destroyed);
    Tank1.destroyed = true;
    Tank2.destroyed = true;
    Tank3.destroyed = true;
    // if (players == "2"){
    //     Tank3.destroyed = true;
    //     Tank3.x = -50;
    //     Tank3.y = -50;
    //     Tank3.WEAPON.x = -50;
    //     Tank3.WEAPON.y = -40;
    // }
    win_cond = 0;
    // console.log(time);
    document.getElementById("time").innerHTML = "Time: " + time;
    setTimeout(function() {
        time = time - 1;    
        // console.log(time);
        document.getElementById("time").innerHTML = "Time: " + time;
        setTimeout(function() {
            time = time - 1;    
            document.getElementById("time").innerHTML = "Time: " + time;
            // console.log(time);
            setTimeout(function() {
                time = time - 1;    
                document.getElementById("time").innerHTML = "Time: " + time;
                // console.log(time);
                Tank1.destroyed = false;
                Tank2.destroyed  = false;
                if (players == "2"){
                    Tank3.destroyed = true;
                }
                else{
                    Tank3.destroyed = false;          
                }
                document.getElementById("time").innerHTML = "";

            }
            ,1000);            
        }
        ,1000);
    }
    ,1000);


    // setTimeout(function() {
    //     // console.log("SETTING FALSE");

    // }, 3000);
    

    c.clearRect(0, 0, canv.width, canv.height);
    if (!Tank1.destroyed){
        Draw_tank1();
        // console.log("1 Survived");
    }
    if (!Tank2.destroyed){
        Draw_tank2();
        // console.log("2 Survived");
    }
    if (!Tank3.destroyed){
        Draw_tank3();
        // console.log("3 Survived");
    }
    do{
            ox = [];
            oy = [];
            cond = 0;
            random_x = Math.floor(Math.random() * 10);
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 4) + 1;
            random_y = random_y * 100;
            
            var ox0 = new obstaclex(random_x, random_y, 100, 15);
            // random_x += 100;
            // random_x = random_x % 800;
            // random_y += 100;
            // random_y = random_y % 450;
            // random_y = Math.floor(Math.random() * 300) + 100;
            random_x = Math.floor(Math.random() * 10);
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 4) + 1;
            random_y = random_y * 100;
            var ox1 = new obstaclex(random_x, random_y, 100, 15);
            // random_x += 100;
            // random_x = random_x % 800;
            // random_y += 100;
            // random_y = random_y % 450;
            // random_y = Math.floor(Math.random() * 300) + 100;
            random_x = Math.floor(Math.random() * 10);
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 4) + 1;
            random_y = random_y * 100;
            var ox2 = new obstaclex(random_x, random_y, 100, 15);
            // random_x += 100;
            // random_x = random_x % 800;
            // random_y += 100;
            // random_y = random_y % 450;
            // random_y = Math.floor(Math.random() * 300) + 100;
            random_x = Math.floor(Math.random() * 10);
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 4) + 1;
            random_y = random_y * 100;
            var ox3 = new obstaclex(random_x, random_y, 100, 15);
            // random_x += 100;
            // random_x = random_x % 800;
            // random_y += 100;
            // random_y = random_y % 450;
            // random_y = Math.floor(Math.random() * 300) + 100;
            random_x = Math.floor(Math.random() * 10);
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 4) + 1;
            random_y = random_y * 100;
            var ox4 = new obstaclex(random_x, random_y, 100, 15);
            // random_x += 100;
            // random_x = random_x % 800;
            // random_y += 100;
            // random_y = random_y % 450;
            random_x = Math.floor(Math.random() * 10);
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 4) + 1;
            random_y = random_y * 100;
            // random_y = Math.floor(Math.random() * 300) + 100;
            var ox5 = new obstaclex(random_x, random_y, 100, 15);
            
            
            
            
            random_x = Math.floor(Math.random() * 8) + 1;
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 5);
            random_y = random_y * 100;
            
            
            
            
            var oy0 = new obstacley(random_x, random_y, 15, 100);
            // random_x += 100;
            // random_x = random_x % 900;
            // if (random_x == 0){
            //     random_x += 100;
            // }
            // random_y += 100;
            // random_y = random_y % 300;
            random_x = Math.floor(Math.random() * 8) + 1;
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 5);
            random_y = random_y * 100;
            var oy1 = new obstacley(random_x, random_y, 15, 100);
            // random_x += 100;
            // random_x = random_x % 900;
            // if (random_x == 0){
            //     random_x += 100;
            // }
            random_x = Math.floor(Math.random() * 8) + 1;
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 5);
            random_y = random_y * 100;
            // if (random_x == 0){
            //     random_x += 100;
            // }
            // random_y += 100;
            // random_y = random_y % 300;
            var oy2 = new obstacley(random_x, random_y, 15, 100);
            // random_x += 100;
            // random_x = random_x % 900;
            // if (random_x == 0){
            //     random_x += 100;
            // }
            // random_y += 100;
            // random_y = random_y % 300;
            random_x = Math.floor(Math.random() * 8) + 1;
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 5);
            random_y = random_y * 100;
            var oy3 = new obstacley(random_x, random_y, 15, 100);
            // random_x += 100;
            // random_x = random_x % 900;
            // if (random_x == 0){
            //     random_x += 100;
            // }
            // random_y += 100;
            // random_y = random_y % 300;
            random_x = Math.floor(Math.random() * 8) + 1;
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 5);
            random_y = random_y * 100;
            var oy4 = new obstacley(random_x, random_y, 15, 100);
            // random_x += 100;
            // random_x = random_x % 900;
            // if (random_x == 0){
            //     random_x += 100;
            // }
            // random_y += 100;
            // random_y = random_y % 450;
            random_x = Math.floor(Math.random() * 8) + 1;
            random_x = random_x * 100;
            random_y = Math.floor(Math.random() * 5);
            random_y = random_y * 100;
            var oy5 = new obstacley(random_x, random_y, 15, 100);
            ox.push(ox0, ox1, ox2, ox3, ox4, ox5);
            oy.push(oy0, oy1, oy2, oy3, oy4, oy5);   
            
            ox.forEach((X) => {
                if (X.getx() == 0){
                    oy.forEach((Y) => {
                        if (Y.gety() == 0){
                            if (X.getx() + X.getw() == Y.gety() + Y.geth()){
                                cond = 1;
                            }
                        }
                        if (Y.getx() == X.getx() + X.getw()){
                            cond = 1;
                        }
                    });
                }
                if (X.getx() + X.getw() == 900){
                    oy.forEach((Y) => {
                        if (Y.gety() + Y.geth() == 500){
                            if (X.getx() == Y.getx() || X.gety() == Y.gety()){
                                cond = 1;
                            }
                        }
                        
                            if (Y.gety() + Y.geth() == X.gety()){
                                // console.log("YESS");
                                cond = 1;
                            }
                        
                    });
                }
                oy.forEach((Y) => {
                    if (X.getx() + X.getw() == Y.getx()){
                        cond = 1;
                    }
                    if (X.getx() + X.getw() == Y.getx() + Y.geth()){
                        cond = 1;
                    }
                    if (Y.getx() + Y.geth() == X.getx()){
                        cond = 1;
                    }
                    if (X.getx() == Y.getx()){
                        cond = 1;
                    }
                });
                
            
            
            });
            
            
            var i = 0;
            var j = 0;
            
            for (i = 0;i < ox.length;i++){
                for (j = 0;j < ox.length;j++){
                    if (i == j && j + 1 < ox.length){
                        j++;
                    }
                    if (ox[i].getx() == ox[j].getx() && ox[i].gety() == ox[j].gety()){
                        ox[j].sety((ox[j].gety() + 100) % 400 + 100);
                    }
                }
            }
            for (i = 0;i < oy.length;i++){
                for (j = 0;j < oy.length;j++){
                    if (i == j && j + 1 < oy.length){
                        j++;
                    }
                    if (oy[i].getx() == oy[j].getx() && oy[i].gety() == oy[j].gety()){
                        oy[j].sety((oy[j].getx() + 100) % 800 + 100);
                    }
                }
            }
            for (i = 0;i < oy.length;i++){
                for (j = 0;j < oy.length;j++){
                    if (i == j && j + 1 < oy.length){
                        j++;
                    }
                    if (oy[i].gety() + 100 == oy[j].gety()){
                        oy[i].setx(oy[i].getx() + 100 % 800);
                    }
                }
            }
            // for (i = 0;i < ox.length;i++){
            //     for (j = 0;j < ox.length;j++){
            //         if (i == j && j + 1 < ox.length){
            //             j++;
            //         }
            //         if (ox[i].getx() + 100 == ox[j].getx()){
            //             ox[i].setx(ox[i].getx() + 100 % 800);
            //         }
            //     }
            // }
            }
            while(cond == 1);
    }    
drawimg_map();























// function DrawBullet(bullet, tank){
//     c.clearRect(0, 0, canv.width, .height);
//     c.save();
//     c.translate(tank.x + tank.w /2, tank.y + tank.h / 2);
//     // c.rotate();
//     c.translate(-(tank.x + tank.w), -(tank.y + tank.h / 2));
//     // c.drawImage(bullet_image, bullet.x, bullet.y, 50, 20);    
//     c.beginPath();
//     c.fillStyle = "#ffffff";
//     c.arc(bullet.x, bullet.y, bullet.r, 0, 2 * Math.PI);      
//     c.fill();
//     c.restore();
// };

var tt1 = {
    x: 0,
    y: 0,
    xw: 0,
    yh: 0
};

function Draw_tank1(){
    c.save();
    c.translate(Tank1.x + Tank1.w / 2, Tank1.y + Tank1.h / 2);
    c.rotate(Tank1.angle);
    c.translate(-(Tank1.x + Tank1.w / 2), -(Tank1.y + Tank1.h / 2));
    // c.drawImage(Tank1_image1, Tank1.x - 5, Tank1.y - 5, Tank1.w + 5, Tank1.h + 5);
    // c.drawImage(Tank1_image2, Tank1.x, Tank1.y, Tank1.w, Tank1.h);
    
    c.drawImage(Tank1_image, Tank1.x, Tank1.y, Tank1.w, Tank1.h);        
    c.drawImage(Tank1_weapon, Tank1.WEAPON.x, Tank1.WEAPON.y, Tank1.WEAPON.w, Tank1.WEAPON.h);
    
    // c.strokeRect(Tank1.x, Tank1.y, Tank1.w, Tank1.h);
     
    // c.fillStyle = "#ffffff";
    // c.fillRect(Tank1.x + 100, Tank1.y + Tank1.h / 2, 100, 100);
    // c.fillRect(Tank1.x + 100 + 200, Tank1.y + Tank1.h / 2, 100, 100);
    // c.strokeStyle = "#ffffff";
    // c.moveTo(Tank1.x + Tank1.w, Tank1.y + (Tank1.h / 2));
    // c.lineTo(Tank1.x + Tank1.w + Math.cos(Tank1.angle) * 100, Tank1.y + (Tank1.h / 2) + Math.sin(Tank1.angle) * 100);
    // c.stroke();
    c.restore();
    // c.beginPath();
};
function Draw_tank2(){
    c.save();
    c.translate(Tank2.x + Tank2.w / 2, Tank2.y + Tank2.h / 2);
    c.rotate(Tank2.angle);
    c.translate(-(Tank2.x + Tank2.w / 2), -(Tank2.y + Tank2.h / 2));
    c.drawImage(Tank2_image, Tank2.x, Tank2.y, Tank2.w, Tank2.h);
    c.drawImage(Tank2_weapon, Tank2.WEAPON.x, Tank2.WEAPON.y, Tank2.WEAPON.w, Tank2.WEAPON.h);
    c.restore();
};
function Draw_tank3(){
    c.save();
    c.translate(Tank3.x + Tank3.w / 2, Tank3.y + Tank3.h / 2);
    c.rotate(Tank3.angle);
    c.translate(-(Tank3.x + Tank3.w / 2), -(Tank3.y + Tank3.h / 2));
    c.drawImage(Tank3_image, Tank3.x, Tank3.y, Tank3.w, Tank3.h);
    c.drawImage(Tank3_weapon, Tank3.WEAPON.x, Tank3.WEAPON.y, Tank3.WEAPON.w, Tank3.WEAPON.h);
    c.restore();
}
function rotation_Tank1() {
    if (pressedKeys[Tank1_KEYS.ARROW_RIGHT]) {
        c.clearRect(0 ,0, canv.width, canv.height);
        create_map();
        draw_all();
        ;
        Tank1.angle = Tank1.angle + 0.0174533 * Tank1.rSpeed;
        Tank1.angle = Tank1.angle % 6.28319;
        // Draw_tank1();
        // console.log(Tank1.angle);
    }
    if (pressedKeys[Tank1_KEYS.ARROW_LEFT]) {
        c.clearRect(0 ,0, canv.width, canv.height);
        create_map();
        draw_all();
     
        Tank1.angle = Tank1.angle - 0.0174533 * Tank1.rSpeed;
        Tank1.angle = Tank1.angle % 6.28319;
        // Draw_tank1();
        // console.log(Tank1.angle);
    }
};
function rotation_Tank2(){
    if (pressedKeys[Tank2_KEYS.ARROW_RIGHT]) {
        // console.log("2");
        c.clearRect(0, 0, canv.width, canv.height);
        draw_all();
        create_map();

        Tank2.angle = Tank2.angle + 0.0174533 * Tank2.rSpeed;
        Tank2.angle = Tank2.angle % 6.28319;
        // Draw_tank2();
        // console.log(Tank2.angle);
    }
    if (pressedKeys[Tank2_KEYS.ARROW_LEFT]) {
        c.clearRect(0, 0, canv.width, canv.height);
        // console.log("2");
        draw_all();
        create_map();

        Tank2.angle = Tank2.angle - 0.0174533 * Tank2.rSpeed;
        Tank2.angle = Tank2.angle % 6.28319;
        // Draw_tank2();
        // console.log(Tank2.angle);
    }
};
function rotation_Tank3(){
    if (pressedKeys[Tank3_KEYS.ARROW_RIGHT]) {
        c.clearRect(0, 0, canv.width, canv.height);
        draw_all();
        create_map();
        Tank3.angle = Tank3.angle + 0.0174533 * Tank3.rSpeed;
        Tank3.angle = Tank3.angle % 6.28319;
        // Draw_tank2();
        // console.log(Tank2.angle);
    }
    if (pressedKeys[Tank3_KEYS.ARROW_LEFT]) {
        c.clearRect(0, 0, canv.width, canv.height);
        draw_all();
        create_map();
        Tank3.angle = Tank3.angle - 0.0174533 * Tank3.rSpeed;
        Tank3.angle = Tank3.angle % 6.28319;
        // Draw_tank2();
        // console.log(Tank2.angle);
    }
};
function Tank_Check_up_x(Tank){
    if ((Tank.x + Tank.w + Math.cos(Tank.angle) * Tank.speed) > canv.width - 13 || (Tank.x + Math.cos(Tank.angle) * Tank.speed) < 13){
        return true;
    }
    else{
        return false;
    }
}
function Tank_Check_up_y(Tank){
    if ((Tank.y + Tank.h + Math.sin(Tank.angle) * Tank.speed) > canv.height - 13 || (Tank.y + Math.sin(Tank.angle) * Tank.speed) < 13){
        return true;
    }
    else{
        return false;
    }
}
function Tank_Check_down_x(Tank){
    if ((Tank.x - Math.cos(Tank.angle) * Tank.speed) < 13 || (Tank.x + Tank.w - Math.cos(Tank.angle) * Tank.speed) > canv.width - 13){
        return true;
    }
    else{
        return false;
    }
}
function Tank_Check_down_y(Tank){
    if ((Tank.y - Math.sin(Tank.angle) * Tank.speed) < 13 || (Tank.y + Tank.h - Math.sin(Tank.angle) * Tank.speed) > canv.height - 13){
        return true;
    }
    else{
        return false;
    }
}





















function checking_obstacle_x(tank){
    var cond = 0;
    // x = Tank1.x + 
    var x = tank.x + Math.cos(tank.angle) * tank.speed ;
    var x2 = tank.x + Math.cos(tank.angle) * tank.speed ;
    var y = tank.y;
    // var y = tank.y + Math.sin(tank.angle) * tank.speed;
    ox.forEach((o) => {
        if (o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y + tank.h && o.gety() + o.geth() > y  ||  o.getx() < x2 + tank.w && o.getx() + o.getw() > x2 && o.gety() < y + tank.h && o.gety() + o.geth() > y){
            cond = 1;            
        }
    });
    oy.forEach((o) => {
        if (o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y + tank.h && o.gety() + o.geth() > y  || o.getx() < x2 + tank.w && o.getx() + o.getw() > x2 && o.gety() < y + tank.h && o.gety() + o.geth() > y){
            cond = 1;            
        }
    });
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}
function checking_obstacle_x_down(tank){
    var cond = 0;
    // x = Tank1.x + 
    var x = tank.x - Math.cos(tank.angle) * tank.speed ;
    var x2 = tank.x - Math.cos(tank.angle) * tank.speed;
    var y = tank.y;
    // var y = tank.y + Math.sin(tank.angle) * tank.speed;
    ox.forEach((o) => {
        if (o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y + tank.h && o.gety() + o.geth() > y  ||  o.getx() < x2 + tank.w && o.getx() + o.getw() > x2 && o.gety() < y + tank.h && o.gety() + o.geth() > y){
            cond = 1;            
        }
    });
    oy.forEach((o) => {
        if (o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y + tank.h && o.gety() + o.geth() > y  || o.getx() < x2 + tank.w && o.getx() + o.getw() > x2 && o.gety() < y + tank.h && o.gety() + o.geth() > y){
            cond = 1;            
        }
    });
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }

}
function checking_obstacle_y(tank){
    var cond = 0;
    // x = Tank1.x + 
    var x = tank.x;
    var y = tank.y + Math.sin(tank.angle) * tank.speed ;
    var y2 = tank.y + Math.sin(tank.angle) * tank.speed ;
    // var y = tank.y + Math.sin(tank.angle) * tank.speed;
    ox.forEach((o) => {
        if (o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y + tank.h && o.gety() + o.geth() > y  || o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y2 + tank.h && o.gety() + o.geth() > y2){
            cond = 1;            
        }
    });
    oy.forEach((o) => {
        if (o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y + tank.h && o.gety() + o.geth() > y  || o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y2 + tank.h && o.gety() + o.geth() > y2){
            cond = 1;            
        }
    });
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}
function checking_obstacle_y_down(tank){
    var cond = 0;
    // x = Tank1.x + 
    var x = tank.x;
    var y = tank.y - Math.sin(tank.angle) * tank.speed ;
    var y2 = tank.y - Math.sin(tank.angle) * tank.speed;
    // var y = tank.y + Math.sin(tank.angle) * tank.speed;
    ox.forEach((o) => {
        if (o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y + tank.h && o.gety() + o.geth() > y  || o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y2 + tank.h && o.gety() + o.geth() > y2){
            cond = 1;            
        }
    });
    oy.forEach((o) => {
        if (o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y + tank.h && o.gety() + o.geth() > y  || o.getx() < x + tank.w && o.getx() + o.getw() > x && o.gety() < y2 + tank.h && o.gety() + o.geth() > y2){
            cond = 1;            
        }
    });
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}




















function check_tank1_x(){
    cond = 0;
    x = Tank1.x + Math.cos(Tank1.angle) * Tank1.speed;
    y = Tank1.y;
    if (x + Tank1.w > Tank2.x && x < Tank2.x + Tank2.w && y + Tank1.h > Tank2.y && y < Tank2.y + Tank2.h){
        cond = 1;     
    }
    if (x + Tank1.w > Tank3.x && x < Tank3.x + Tank3.w && y + Tank1.h > Tank3.y && y < Tank3.y + Tank3.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}
function check_tank1_y(){
    cond = 0;
    x = Tank1.x;
    y = Tank1.y + Math.sin(Tank1.angle) * Tank1.speed;
    if (x + Tank1.w > Tank2.x && x < Tank2.x + Tank2.w && y + Tank1.h > Tank2.y && y < Tank2.y + Tank2.h){
        cond = 1;     
    }
    if (x + Tank1.w > Tank3.x && x < Tank3.x + Tank3.w && y + Tank1.h > Tank3.y && y < Tank3.y + Tank3.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}











function check_tank1_x_down(){
    cond = 0;
    x = Tank1.x - Math.cos(Tank1.angle) * Tank1.speed;
    y = Tank1.y;
    if (x + Tank1.w > Tank2.x && x < Tank2.x + Tank2.w && y + Tank1.h > Tank2.y && y < Tank2.y + Tank2.h){
        cond = 1;     
    }
    if (x + Tank1.w > Tank3.x && x < Tank3.x + Tank3.w && y + Tank1.h > Tank3.y && y < Tank3.y + Tank3.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}
function check_tank1_y_down(){
    cond = 0;
    x = Tank1.x ;
    y = Tank1.y - Math.sin(Tank1.angle) * Tank1.speed;
    if (x + Tank1.w > Tank2.x && x < Tank2.x + Tank2.w && y + Tank1.h > Tank2.y && y < Tank2.y + Tank2.h){
        cond = 1;     
    }
    if (x + Tank1.w > Tank3.x && x < Tank3.x + Tank3.w && y + Tank1.h > Tank3.y && y < Tank3.y + Tank3.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}
























function check_tank2_x(){
    cond = 0;
    x = Tank2.x + Math.cos(Tank2.angle) * Tank2.speed;
    y = Tank2.y;
    if (x + Tank2.w > Tank1.x && x < Tank1.x + Tank1.w && y + Tank2.h > Tank1.y && y < Tank1.y + Tank1.h){
        cond = 1;     
    }
    if (x + Tank2.w > Tank3.x && x < Tank3.x + Tank3.w && y + Tank2.h > Tank3.y && y < Tank3.y + Tank3.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}
function check_tank2_y(){
    cond = 0;
    x = Tank2.x;
    y = Tank2.y + Math.sin(Tank2.angle) * Tank2.speed;
    if (x + Tank2.w > Tank1.x && x < Tank1.x + Tank1.w && y + Tank2.h > Tank1.y && y < Tank1.y + Tank1.h){
        cond = 1;     
    }
    if (x + Tank2.w > Tank3.x && x < Tank3.x + Tank3.w && y + Tank2.h > Tank3.y && y < Tank3.y + Tank3.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}













function check_tank2_x_down(){
    cond = 0;
    x = Tank2.x - Math.cos(Tank2.angle) * Tank2.speed;
    y = Tank2.y;
    if (x + Tank2.w > Tank1.x && x < Tank1.x + Tank1.w && y + Tank2.h > Tank1.y && y < Tank1.y + Tank1.h){
        cond = 1;     
    }
    if (x + Tank2.w > Tank3.x && x < Tank3.x + Tank3.w && y + Tank2.h > Tank3.y && y < Tank3.y + Tank3.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}
function check_tank2_y_down(){
    cond = 0;
    x = Tank2.x;
    y = Tank2.y - Math.sin(Tank2.angle) * Tank2.speed;
    if (x + Tank2.w > Tank1.x && x < Tank1.x + Tank1.w && y + Tank2.h > Tank1.y && y < Tank1.y + Tank1.h){
        cond = 1;     
    }
    if (x + Tank2.w > Tank3.x && x < Tank3.x + Tank3.w && y + Tank2.h > Tank3.y && y < Tank3.y + Tank3.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}














function check_tank3_x(){
    cond = 0;
    x = Tank3.x + Math.cos(Tank3.angle) * Tank3.speed;
    y = Tank3.y;
    if (x + Tank3.w > Tank1.x && x < Tank1.x + Tank1.w && y + Tank3.h > Tank1.y && y < Tank1.y + Tank1.h){
        cond = 1;     
    }
    if (x + Tank3.w > Tank2.x && x < Tank2.x + Tank2.w && y + Tank3.h > Tank2.y && y < Tank2.y + Tank2.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}

function check_tank3_y(){
    cond = 0;
    x = Tank3.x ;
    y = Tank3.y + Math.sin(Tank3.angle) * Tank3.speed;
    if (x + Tank3.w > Tank1.x && x < Tank1.x + Tank1.w && y + Tank3.h > Tank1.y && y < Tank1.y + Tank1.h){
        cond = 1;     
    }
    if (x + Tank3.w > Tank2.x && x < Tank2.x + Tank2.w && y + Tank3.h > Tank2.y && y < Tank2.y + Tank2.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}


















function check_tank3_x_down(){
    cond = 0;
    x = Tank3.x - Math.cos(Tank3.angle) * Tank3.speed;
    y = Tank3.y;
    if (x + Tank3.w > Tank1.x && x < Tank1.x + Tank1.w && y + Tank3.h > Tank1.y && y < Tank1.y + Tank1.h){
        cond = 1;     
    }
    if (x + Tank3.w > Tank2.x && x < Tank2.x + Tank2.w && y + Tank3.h > Tank2.y && y < Tank2.y + Tank2.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}

function check_tank3_y_down(){
    cond = 0;
    x = Tank3.x ;
    y = Tank3.y - Math.sin(Tank3.angle) * Tank3.speed;
    if (x + Tank3.w > Tank1.x && x < Tank1.x + Tank1.w && y + Tank3.h > Tank1.y && y < Tank1.y + Tank1.h){
        cond = 1;     
    }
    if (x + Tank3.w > Tank2.x && x < Tank2.x + Tank2.w && y + Tank3.h > Tank2.y && y < Tank2.y + Tank2.h){
        cond = 1;     
    }
    if (cond == 1){
        return false;
    }
    else{
        return true;
    }
}























function movement_Tank1(){    
    if (pressedKeys[Tank1_KEYS.ARROW_UP]){
        c.clearRect(0 ,0, canv.width, canv.height);
        // c.strokeRect(Tank1.x, Tank1.y, Tank1.w, Tank1.h);
        create_map();
        draw_all();
        ;
        // console.log(checking_obstacle(Tank1));
        if (!Tank_Check_up_x(Tank1) && checking_obstacle_x(Tank1) && check_tank1_x()){
            Tank1.x += Math.cos(Tank1.angle) * Tank1.speed;
            Tank1.WEAPON.x += Math.cos(Tank1.angle) * Tank1.speed;
        }
        if (!Tank_Check_up_y(Tank1) && checking_obstacle_y(Tank1) && check_tank1_y()){
            Tank1.y += Math.sin(Tank1.angle) * Tank1.speed;
            Tank1.WEAPON.y += Math.sin(Tank1.angle) * Tank1.speed;
        }
        // Draw_tank1();
        // console.log("X: " + Math.cos(Tank1.angle) + " Y: " + Math.sin(Tank1.angle));
        // console.log("X: " + Tank1.x + " Y: " + Tank1.y);
    }
    if (pressedKeys[Tank1_KEYS.ARROW_DOWN]){
        c.clearRect(0 ,0, canv.width, canv.height);
        // c.strokeRect(Tank1.x, Tank1.y, Tank1.w, Tank1.h);
        ;
        create_map();
        draw_all();
        if (!Tank_Check_down_x(Tank1) && checking_obstacle_x_down(Tank1) && check_tank1_x_down()){
            Tank1.x -= Math.cos(Tank1.angle) * Tank1.speed;
            Tank1.WEAPON.x -= Math.cos(Tank1.angle) * Tank1.speed;
        }
        if (!Tank_Check_down_y(Tank1) && checking_obstacle_y_down(Tank1) && check_tank1_y_down()){
            Tank1.y -= Math.sin(Tank1.angle) * Tank1.speed;
            Tank1.WEAPON.y -= Math.sin(Tank1.angle) * Tank1.speed;
        }
        // Draw_tank1();
        // console.log("X: " + Tank1.x + " Y: " + Tank1.y);
    }
    // create_map();    

};
function movement_Tank2(){
    if (pressedKeys[Tank2_KEYS.ARROW_UP]){
        c.clearRect(0, 0, canv.width, canv.height);
        draw_all();
        create_map();
        ;
        if (!Tank_Check_up_x(Tank2) && checking_obstacle_x(Tank2) && check_tank2_x()){
            Tank2.x += Math.cos(Tank2.angle) * Tank2.speed;
            Tank2.WEAPON.x += Math.cos(Tank2.angle) * Tank2.speed;
        }
        if (!Tank_Check_up_y(Tank2) && checking_obstacle_y(Tank2) && check_tank2_y()){
            Tank2.y += Math.sin(Tank2.angle) * Tank2.speed;
            Tank2.WEAPON.y += Math.sin(Tank2.angle) * Tank2.speed;
        }
        // Draw_tank2();
        // console.log("X: " + Tank2.x + " Y: " + Tank2.y);
    }
    if (pressedKeys[Tank2_KEYS.ARROW_DOWN]){
        c.clearRect(0, 0, canv.width, canv.height);
        draw_all();
        create_map();
        ;
        if (!Tank_Check_down_x(Tank2) && checking_obstacle_x_down(Tank2) && check_tank2_x_down()){
            Tank2.x -= Math.cos(Tank2.angle) * Tank2.speed;
            Tank2.WEAPON.x -= Math.cos(Tank2.angle) * Tank2.speed;    
        }

        if (!Tank_Check_down_y(Tank2) && checking_obstacle_y_down(Tank2) && check_tank2_y_down()){
            Tank2.y -= Math.sin(Tank2.angle) * Tank2.speed;
            Tank2.WEAPON.y -= Math.sin(Tank2.angle) * Tank2.speed;
        }

        // Draw_tank2();
        // console.log("X: " + Tank2.x + " Y: " + Tank2.y);
    }
}
function movement_Tank3(){
    if (pressedKeys[Tank3_KEYS.ARROW_UP]){
        c.clearRect(0, 0, canv.width, canv.height);
        draw_all();
        create_map();
        ;
        if (!Tank_Check_up_x(Tank3) && checking_obstacle_x(Tank3) && check_tank3_x()){
            Tank3.x += Math.cos(Tank3.angle) * Tank3.speed;
            Tank3.WEAPON.x += Math.cos(Tank3.angle) * Tank3.speed;
        }
        if (!Tank_Check_up_y(Tank3) && checking_obstacle_y(Tank3) && check_tank3_y()){
            Tank3.y += Math.sin(Tank3.angle) * Tank3.speed;
            Tank3.WEAPON.y += Math.sin(Tank3.angle) * Tank3.speed;
        }
        // Draw_tank2();
        // console.log("X: " + Tank2.x + " Y: " + Tank2.y);
    }
    if (pressedKeys[Tank3_KEYS.ARROW_DOWN]){
        c.clearRect(0, 0, canv.width, canv.height);
        draw_all();
        create_map();
        ;
        if (!Tank_Check_down_x(Tank3) && checking_obstacle_x_down(Tank3) && check_tank3_x_down()){
            Tank3.x -= Math.cos(Tank3.angle) * Tank3.speed;
            Tank3.WEAPON.x -= Math.cos(Tank3.angle) * Tank3.speed;    
        }

        if (!Tank_Check_down_y(Tank3) && checking_obstacle_y_down(Tank3) && check_tank3_y_down()){
            Tank3.y -= Math.sin(Tank3.angle) * Tank3.speed;
            Tank3.WEAPON.y -= Math.sin(Tank3.angle) * Tank3.speed;
        }

        // Draw_tank2();
        // console.log("X: " + Tank2.x + " Y: " + Tank2.y);
    }
}
function UpdateBullet(){
    bullet.x = bullet.x + Math.cos(Tank1.angle);
    bullet.y = bullet.y + Math.sin(Tank1.angle);
    // console.log("THIS IS THE BULLET : X: " + Math.cos(Tank1.angle) + " Y: " + Math.sin(Tank1.angle));
    }

function Shooting_Tank1(){
    var c1 = 0;
    if (pressedKeys[Tank1_KEYS.SHOOT_KEY] && Tank1.normal){
        bullets.forEach((b) => {
            if (b.check_color()){
                if (b.get_tank() == Tank1){
                    b.set_duration(0);
                    c1 = 1;
                    if (bullet_sound.duration > 0 && !bullet_sound.paused){
                        bullet_sound.currentTime = 0.05;
                        bullet_sound.play();
                    }   
                    else{
                        bullet_sound.play();
                    }
                }
            }
        });
    }
    if (pressedKeys[Tank1_KEYS.SHOOT_KEY] && Tank1.bullet_count < 4 && Tank1.normal){        
        if (c1 == 0){
            var b = new bullet(Tank1.x + Tank1.w / 2, Tank1.y + (Tank1.h / 2), 4, Math.cos(Tank1.angle) * bullet_speed, Math.sin(Tank1.angle) * bullet_speed, Tank1, 5000, "#ffffff");
            // console.log(Math.cos(Tank1.angle) * 5);
            // firing_animation(Tank1);
            if (bullet_sound.duration > 0 && !bullet_sound.paused){
                bullet_sound.currentTime = 0.05;
                bullet_sound.play();
            }   
            else{
                bullet_sound.play();
            }
            // bullet_sound.play();
            // bullet_sound.ended();
            // setTimeout(function() {
            //     bullet_sound.pause();
            //     bullet_sound.currentTime = 0;
            // }, 200); 
            b.first_update();
            bullets.push(b);
            Tank1.bullet_count++;
            
        }
        
    }
    if (pressedKeys[Tank1_KEYS.SHOOT_KEY] && Tank1.bomb){
        var b = new bullet(Tank1.x + Tank1.w / 2, Tank1.y + (Tank1.h / 2), 5, Math.cos(Tank1.angle) * bullet_speed, Math.sin(Tank1.angle) * bullet_speed, Tank1, 1500, "red");
        if (bullet_sound.duration > 0 && !bullet_sound.paused){
            bullet_sound.currentTime = 0.05;
            bullet_sound.play();
        }   
        else{
            bullet_sound.play();
        }
        b.first_update();
        bullets.push(b);
        Tank1.bomb = false;
        Tank1.normal = true;
            // setTimeout(function() {
            //     bullet_sound.pause();
            //     bullet_sound.currentTime = 0;
            // }, 900);
    }
    pressedKeys[Tank1_KEYS.SHOOT_KEY] = false;
}
function Shooting_Tank2(){
    var c2 = 0;
    if (pressedKeys[Tank2_KEYS.SHOOT_KEY] && Tank2.normal){
        bullets.forEach((b) => {
            if (b.check_color()){
                if (b.get_tank() == Tank2){
                    b.set_duration(0);
                    c2 = 1;
                    if (bullet_sound.duration > 0 && !bullet_sound.paused){
                        bullet_sound.currentTime = 0.05;
                        bullet_sound.play();
                    }   
                    else{
                        bullet_sound.play();
                    }
                }
            }
        });
    }
    if(pressedKeys[Tank2_KEYS.SHOOT_KEY] && Tank2.bullet_count < 4 && Tank2.normal){
        
        if (c2 == 0){
            var b = new bullet(Tank2.x + Tank2.w / 2, Tank2.y + (Tank2.h / 2), 4, Math.cos(Tank2.angle) * bullet_speed, Math.sin(Tank2.angle) * bullet_speed, Tank2, 5000, "#ffffff");
            if (bullet_sound.duration > 0 && !bullet_sound.paused){
                bullet_sound.currentTime = 0.05;
                bullet_sound.play();
            }   
            else{
                bullet_sound.play();
            }
            b.first_update();
            bullets.push(b);
            Tank2.bullet_count++;
        }
    }
    if (pressedKeys[Tank2_KEYS.SHOOT_KEY] && Tank2.bomb){
        var b = new bullet(Tank2.x + Tank2.w / 2, Tank2.y + (Tank2.h / 2), 5, Math.cos(Tank2.angle) * bullet_speed, Math.sin(Tank2.angle) * bullet_speed, Tank2, 1500, "red");
        if (bullet_sound.duration > 0 && !bullet_sound.paused){
            bullet_sound.currentTime = 0.05;
            bullet_sound.play();
        }   
        else{
            bullet_sound.play();
        }
        b.first_update();
        bullets.push(b);
        Tank2.bomb = false;
        Tank2.normal = true;
    }
    pressedKeys[Tank2_KEYS.SHOOT_KEY] = false;
}
function Shooting_Tank3(){
    var c3 = 0;
    if (pressedKeys[Tank3_KEYS.SHOOT_KEY] && Tank3.normal){
        bullets.forEach((b) => {
            if (b.check_color()){
                if (b.get_tank() == Tank3){
                    b.set_duration(0);
                    c3 = 1;
                    if (bullet_sound.duration > 0 && !bullet_sound.paused){
                        bullet_sound.currentTime = 0.05;
                        bullet_sound.play();
                    }   
                    else{
                        bullet_sound.play();
                    }
                }
            }
        });
    }
    if(pressedKeys[Tank3_KEYS.SHOOT_KEY] && Tank3.bullet_count < 4 && Tank3.normal){
        if (c3 == 0){
            var b = new bullet(Tank3.x + Tank3.w / 2, Tank3.y + (Tank3.h / 2), 4, Math.cos(Tank3.angle) * bullet_speed, Math.sin(Tank3.angle) * bullet_speed, Tank3, 5000, "#ffffff");
            if (bullet_sound.duration > 0 && !bullet_sound.paused){
                bullet_sound.currentTime = 0.05;
                bullet_sound.play();
            }   
            else{
                bullet_sound.play();
            }
            b.first_update();
            bullets.push(b);
            Tank3.bullet_count++;
        }
    }
    if (pressedKeys[Tank3_KEYS.SHOOT_KEY] && Tank3.bomb){
        var b = new bullet(Tank3.x + Tank3.w / 2, Tank3.y + (Tank3.h / 2), 5, Math.cos(Tank3.angle) * bullet_speed, Math.sin(Tank3.angle) * bullet_speed, Tank3, 1500, "red");
        if (bullet_sound.duration > 0 && !bullet_sound.paused){
            bullet_sound.currentTime = 0.05;
            bullet_sound.play();
        }   
        else{
            bullet_sound.play();
        }
        b.first_update();
        bullets.push(b);
        Tank3.bomb = false;
        Tank3.normal = true;
    }
    pressedKeys[Tank3_KEYS.SHOOT_KEY] = false;
}
var bx = Math.floor(Math.random() * 9);
var by = Math.floor(Math.random() * 5);
bx = bx * 100;
by = by * 100;
bx += 35;
by += 35;
var bomb_cond = false;
function show_power(){
    bomb_cond = true;
}
setTimeout("show_power()", 15000);
function calling_bomb(){
    setTimeout("show_power()", 15000);
    // console.log("IM IN");
    bx = Math.floor(Math.random() * 9);
    by = Math.floor(Math.random() * 5);    
    bx = bx * 100;
    by = by * 100;
    bx += 35;
    by += 35;

}
function power_collision(tank){
    if (tank.x + tank.w > bx && bx + 30 > tank.x && tank.y + tank.h > by && by + 30 > tank.y)
    {
        tank.normal = false;
        tank.bomb = true;
        // console.log("GOT POWER UP!!");
        power_sound.play();
        bomb_cond = false;
        calling_bomb();
    }
}




function showing_bomb(){
    if (bomb_cond){
        c.drawImage(power, bx, by, 30, 30);
    }
}



function sleep(miliseconds) {
    var currentTime = new Date().getTime();
    temp = miliseconds;
    while (currentTime + miliseconds >= new Date().getTime()) {
    }
 }




function checking_win(){
    win_cond = 0;
    if (players == "2"){
        // Tank3.destroyed = true;
        Tank3.x = -50;
        Tank3.y = -50;
        Tank3.WEAPON.x = -50;
        Tank3.WEAPON.y = -40;
    }
    var cond1 = false;
    var cond2 = false;
    var cond3 = false;
    if (Tank1.destroyed){
        win_cond++;
    }
    else{
        Draw_tank1();    
    }
    if (Tank2.destroyed){
        win_cond++;
    }
    else{
        Draw_tank2();
    }
    if (Tank3.destroyed){
        win_cond++;
    }
    else{
        Draw_tank3();
    }
    if (win_cond == 2){
        // if(Tank1.destroyed){
        //     Tank1.destroyed = false;            
        // }
        // else{
        //     score1++;
        // }
        // if(Tank2.destroyed){
        //     Tank2.destroyed = false;

        // }
        // else{
        //     score2++;
        // }
        // if(Tank3.destroyed){
        //     Tank3.destroyed = false;
            
        // }
        // else{
        //     score3++;
        // }
        if(Tank1.destroyed){
            Tank1.destroyed = false;            
        }
        else{
            // score1++;
            // check_score = 1;
            cond1 = true;
        }
        if(Tank2.destroyed){
            Tank2.destroyed = false;

        }
        else{
            // score2++;
            // check_score = 2;
            cond2 = true;
        }
        if(Tank3.destroyed){
            // if (players == "2"){

            // }
            // else{
                Tank3.destroyed = false;
            // }
        }
        else{
            // score3++;
            // check_score = 3;
            cond3 = true;
        }
        setTimeout(function() {
            // if (cond1 && Tank1.destroyed){
            console.log(win_cond);  
            // }
            // console.clear();
            // console.log(win_cond);
            // console.log("DES 1: " + Tank1.destroyed);
            // console.log("DES 2: " + Tank2.destroyed);
            console.log("DES 3: " + Tank3.destroyed);
            // console.log("COND 1: " + cond1);
            // console.log("COND 2: " + cond2);
            console.log("COND 3: " + cond3);
            // console.log("AGAIN: " + Tank1.destroyed);
            if (cond1 && !Tank1.destroyed){
                // console.log("TANK1 WALI CHAL RHI");
                score1++;
            }
            if (cond2 && !Tank2.destroyed){
                // console.log("TANK2 WALI CHAL RHI.");
                score2++;
            }
            if (cond3 && !Tank3.destroyed){
                score3++;
            }
            // console.log("IN THE TIMED FUNCTION.");
            bullets.length = 0;
            Tank1.x = 25;
            Tank1.y = 25;
            Tank1.WEAPON.x = 25;
            Tank1.WEAPON.y = 35;
            Tank2.x = 430;
            Tank2.y = 440;
            Tank2.WEAPON.x = 430;
            Tank2.WEAPON.y = 450;
            Tank3.x = 830;
            Tank3.y = 25;
            Tank3.WEAPON.x = 830;
            Tank3.WEAPON.y = 35;            
            Tank1.bullet_count = 0;
            Tank2.bullet_count = 0;
            Tank3.bullet_count = 0;
            win_cond = 0;
            drawimg_map();
            // console.log(score1);
        }, 3000);              
    }
}

var isPlaying = function () {
    return bullet_sound
        && bullet_sound.currentTime > 0
        && !bullet_sound.paused
        && !bullet_sound.ended
        && bullet_sound.readyState > 2;
}


function gameCycle() {
    // c.clearRect(0 ,0, canv.width, canv.height); 
    checking_win();
    // console.log(win_cond);
    // c.fillRect(Tank1.WEAPON.x, Tank1.WEAPON.y, Tank1.WEAPON.w, Tank1.WEAPON.h);
    // c.fillRect(Tank1.x + Tank1.w, Tank1.y + Tank1.h / 2, 5, 5);
    // c.fillRect(Tank1.x, Tank1.y, Tank1.w, Tank1.h);
    // c.fillRect(Tank2.x, Tank2.y, Tank2.w, Tank2.h);
    
    // c.strokeRect(tt1.x, tt1.y, tt1.xw, tt1.yh);
    // c.drawImage(background_image, 0, 0, canv.width, canv.height);
    create_map();    
    showing_bomb();
    power_collision(Tank1);
    power_collision(Tank2);
    power_collision(Tank3);
    
    // firing_animation();
    // draw_all();
    if (!Tank1.destroyed){
        Draw_tank1();
        rotation_Tank1();        
        movement_Tank1();
        Shooting_Tank1();   
    }
    if (!Tank2.destroyed){
        // console.log("2");
        Draw_tank2();
        rotation_Tank2();
        movement_Tank2();
        Shooting_Tank2();
    }
    if (!Tank3.destroyed){
        // console.log("3");
        Draw_tank3();
        rotation_Tank3();
        movement_Tank3();
        Shooting_Tank3();
    }
    c.strokeStyle = "#ffffff";
    Draw_tank1();    
    Draw_tank2();
    Draw_tank3();
    collision(Tank1);
    collision(Tank2);
    collision(Tank3);

    // console.log("Bullets_Tank1: " + Tank1.bullet_count);
    for (var i = 0;i < bullets.length;i++){
        // console.log(bullets[i].get_x());
        if (bullets[i].bullet_end()){
            if (bullets[i].check_color()){
                var b1 = new bullet(bullets[i].get_x(), bullets[i].get_y(), 4, 4, 0, null, 2500, "#ffffff");
                var b2 = new bullet(bullets[i].get_x(), bullets[i].get_y(), 4, -4, 0, null, 2500, "#ffffff");
                var b3 = new bullet(bullets[i].get_x(), bullets[i].get_y(), 4, 0, 4, null, 2500, "#ffffff");
                var b4 = new bullet(bullets[i].get_x(), bullets[i].get_y(), 4, 0, -4, null, 2500, "#ffffff");
                bullets.push(b1);
                bullets.push(b2);
                bullets.push(b3);
                bullets.push(b4);
            }
            else{
                if (bullets[i].get_tank() != null){
                    bullets[i].get_tank().bullet_count--;
                }
            }
            bullets.splice(i, 1);
            c.clearRect(0, 0,canv.width, canv.height);
            if (!Tank1.destroyed){
                Draw_tank1();
            }
            if (!Tank2.destroyed){
                Draw_tank2();
            }
            if (!Tank3.destroyed){
                Draw_tank3();
            }
        }
        else{
            bullets[i].update();
        }
    }
    if (Tank1.bomb){
        document.getElementById("tank1").style.color = "RED";
    }
    else{
        document.getElementById("tank1").style.color = "GREEN";
    }
    if (Tank2.bomb){
        document.getElementById("tank2").style.color = "RED";
    }    
    else{
        document.getElementById("tank2").style.color = "GREEN";
    }
    if (Tank2.bomb){
        document.getElementById("tank2").style.color = "RED";
    }
    else{
        document.getElementById("tank2").style.color = "GREEN";
    }
    // console.log(win_cond);

    // console.log(players);
    document.getElementById("tank1").innerHTML = "TANK 1 : " + score1;
    document.getElementById("tank2").innerHTML = "TANK 2 : " + score2;
    if (players == "2"){
        document.getElementById("weapon3").style.display = "none";
    }
    else{
    document.getElementById("tank3").innerHTML = "TANK 3 : " + score3;

    }
    window.requestAnimationFrame(gameCycle);
};
gameCycle();